# MeshChat Proguard Rules
-keepattributes *Annotation*
-keepclassmembers class * {
    @androidx.room.* *;
}
-keep class com.meshchat.app.mesh.MeshPacket { *; }
-keep class com.meshchat.app.mesh.PacketType { *; }
-keep class com.meshchat.app.data.MessageEntity { *; }

package com.meshchat.app.mesh

import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.nio.charset.StandardCharsets
import java.util.UUID

@Serializable
enum class PacketType {
    CHAT,
    ACK,
    HEARTBEAT
}

@Serializable
data class MeshPacket(
    val packetId: String = UUID.randomUUID().toString(),
    val type: PacketType = PacketType.CHAT,
    val senderId: String,
    val senderNickname: String,
    val recipientId: String = "*",
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val hopCount: Int = 0,
    val maxHops: Int = 4,
    val traversedPath: List<String> = emptyList()
) {
    fun toBytes(): ByteArray {
        val jsonString = jsonInstance.encodeToString(this)
        return jsonString.toByteArray(StandardCharsets.UTF_8)
    }

    companion object {
        private val jsonInstance = Json {
            ignoreUnknownKeys = true
            encodeDefaults = true
        }

        fun fromBytes(bytes: ByteArray): MeshPacket? {
            return try {
                val jsonString = String(bytes, StandardCharsets.UTF_8)
                jsonInstance.decodeFromString<MeshPacket>(jsonString)
            } catch (e: Exception) {
                null
            }
        }
    }
}

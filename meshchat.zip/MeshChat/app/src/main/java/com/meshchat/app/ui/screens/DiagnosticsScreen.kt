package com.meshchat.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.meshchat.app.ui.MeshStats
import com.meshchat.app.ui.theme.CrimsonRed
import com.meshchat.app.ui.theme.CyberCyan
import com.meshchat.app.ui.theme.DarkBackground
import com.meshchat.app.ui.theme.DarkSurface
import com.meshchat.app.ui.theme.DarkSurfaceVariant
import com.meshchat.app.ui.theme.EmeraldGreen
import com.meshchat.app.ui.theme.TextMuted
import com.meshchat.app.ui.theme.TextSecondary
import com.meshchat.app.ui.theme.WarningAmber

@Composable
fun DiagnosticsScreen(
    stats: MeshStats,
    diagnosticLogs: List<String>,
    onClearHistory: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Section: Packet Flow Statistics
        item {
            Text(
                text = "MESH PACKET METRICS",
                style = MaterialTheme.typography.labelSmall,
                color = CyberCyan,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MetricCard(title = "Sent", count = stats.sent, color = CyberCyan, modifier = Modifier.weight(1f))
                MetricCard(title = "Received", count = stats.received, color = EmeraldGreen, modifier = Modifier.weight(1f))
                MetricCard(title = "Relayed", count = stats.relayed, color = WarningAmber, modifier = Modifier.weight(1f))
                MetricCard(title = "Loops Blocked", count = stats.duplicatesDropped, color = CrimsonRed, modifier = Modifier.weight(1f))
            }
        }

        // Section: Live Packet & Event Logs
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Terminal, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(18.dp))
                            Text(
                                text = "Live Mesh Radio Log",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            text = "${diagnosticLogs.size} events",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextMuted
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Surface(
                        color = Color(0xFF06090F),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(160.dp)
                    ) {
                        if (diagnosticLogs.isEmpty()) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = "Waiting for mesh events...",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = TextMuted
                                )
                            }
                        } else {
                            LazyColumn(
                                modifier = Modifier.padding(8.dp),
                                reverseLayout = true
                            ) {
                                items(diagnosticLogs.reversed()) { log ->
                                    Text(
                                        text = log,
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = 10.sp
                                        ),
                                        color = when {
                                            log.contains("Connected") -> EmeraldGreen
                                            log.contains("Relayed") -> WarningAmber
                                            log.contains("Loop") || log.contains("failed") -> CrimsonRed
                                            else -> TextSecondary
                                        },
                                        modifier = Modifier.padding(vertical = 1.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Section: Architecture & Limitations Guide
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Shield, contentDescription = null, tint = EmeraldGreen)
                        Text(
                            text = "Technical Architecture & Constraints",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))

                    DocItem(
                        title = "1. P2P_CLUSTER Mesh Strategy",
                        desc = "Uses Google Nearby Connections P2P_CLUSTER strategy (M-to-N multi-peer mesh). Devices advertise and discover concurrently. Radio hardware negotiates BLE for discovery and switches automatically to high-bandwidth Wi-Fi Direct or Bluetooth RFCOMM for byte payload transfers."
                    )
                    DocItem(
                        title = "2. Multi-Hop Forwarding & Loop Suppression",
                        desc = "Every packet carries a unique UUID, hopCount, maxHops (4), and traversedPath. When Node B receives a packet from Node A, it logs the UUID in an LRU memory ring-buffer. Duplicate packets are dropped immediately. If hops < 4, Node B relays the packet to all other connected nodes (excluding Node A)."
                    )
                    DocItem(
                        title = "3. Google Play Services Dependency",
                        desc = "The Nearby Connections client runs inside Google Play Services (com.google.android.gms). Real Android devices require Google Play Services installed. De-Googled devices without microG or GMS will not initialize the Nearby API."
                    )
                    DocItem(
                        title = "4. Background Execution & Android 14+",
                        desc = "Android limits background radio scanning to conserve battery. MeshChat includes a Foreground Service (type: connectedDevice) with a persistent notification to keep peer links active when the phone is locked."
                    )
                    DocItem(
                        title = "5. Local Persistence (Room)",
                        desc = "All sent and received messages are stored in local SQLite via Room with delivery states (SENDING, SENT, DELIVERED, RELAYED, FAILED). No internet or external servers are ever accessed."
                    )
                }
            }
        }

        // Action: Clear local history
        item {
            OutlinedButton(
                onClick = onClearHistory,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(imageVector = Icons.Default.DeleteSweep, contentDescription = null, tint = CrimsonRed)
                Spacer(modifier = Modifier.size(8.dp))
                Text(text = "Clear Local Message Database", color = CrimsonRed)
            }
        }
    }
}

@Composable
fun MetricCard(
    title: String,
    count: Int,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = "$count", style = MaterialTheme.typography.titleLarge, color = color, fontWeight = FontWeight.Bold)
            Text(text = title, style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp), color = TextMuted)
        }
    }
}

@Composable
fun DocItem(title: String, desc: String) {
    Column(modifier = Modifier.padding(vertical = 6.dp)) {
        Text(text = title, style = MaterialTheme.typography.bodyMedium, color = CyberCyan, fontWeight = FontWeight.SemiBold)
        Text(text = desc, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
    }
}

package com.meshchat.app.mesh

import android.content.Context
import android.util.Log
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.AdvertisingOptions
import com.google.android.gms.nearby.connection.ConnectionInfo
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback
import com.google.android.gms.nearby.connection.ConnectionResolution
import com.google.android.gms.nearby.connection.ConnectionsClient
import com.google.android.gms.nearby.connection.ConnectionsStatusCodes
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo
import com.google.android.gms.nearby.connection.DiscoveryOptions
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback
import com.google.android.gms.nearby.connection.Payload
import com.google.android.gms.nearby.connection.PayloadCallback
import com.google.android.gms.nearby.connection.PayloadTransferUpdate
import com.google.android.gms.nearby.connection.Strategy
import com.meshchat.app.data.AppDatabase
import com.meshchat.app.data.DeliveryStatus
import com.meshchat.app.data.MessageEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Collections
import java.util.UUID

class NearbyMeshManager(private val context: Context) {

    private val tag = "NearbyMeshManager"
    private val serviceId = "com.meshchat.app.SERVICE_ID"
    private val strategy = Strategy.P2P_CLUSTER

    private val connectionsClient: ConnectionsClient = Nearby.getConnectionsClient(context)
    private val database: AppDatabase = AppDatabase.getDatabase(context)
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    // Unique local device identity
    val localDeviceId: String = UUID.randomUUID().toString().substring(0, 8)
    var localNickname: String = "Node-$localDeviceId"

    // Peer endpoints tracking: endpointId -> PeerDevice
    private val _peers = MutableStateFlow<Map<String, PeerDevice>>(emptyMap())
    val peers: StateFlow<Map<String, PeerDevice>> = _peers.asStateFlow()

    // Mesh status
    private val _isAdvertising = MutableStateFlow(false)
    val isAdvertising: StateFlow<Boolean> = _isAdvertising.asStateFlow()

    private val _isDiscovering = MutableStateFlow(false)
    val isDiscovering: StateFlow<Boolean> = _isDiscovering.asStateFlow()

    // Diagnostics & Statistics
    val packetsSent = MutableStateFlow(0)
    val packetsReceived = MutableStateFlow(0)
    val packetsRelayed = MutableStateFlow(0)
    val packetsDroppedDuplicates = MutableStateFlow(0)

    private val _diagnosticLogs = MutableStateFlow<List<String>>(emptyList())
    val diagnosticLogs: StateFlow<List<String>> = _diagnosticLogs.asStateFlow()

    // Ring-buffer LRU for seen message IDs to prevent loop storms in mesh
    private val seenMessageIds = Collections.synchronizedSet(object : LinkedHashSet<String>() {
        override fun add(element: String): Boolean {
            if (size > 2000) {
                val iterator = iterator()
                if (iterator.hasNext()) {
                    iterator.next()
                    iterator.remove()
                }
            }
            return super.add(element)
        }
    })

    // Active pending connection attempts to avoid simultaneous double-connect collision
    private val pendingConnectingEndpoints = Collections.synchronizedSet(mutableSetOf<String>())

    private fun logDiag(message: String) {
        Log.d(tag, message)
        _diagnosticLogs.value = (_diagnosticLogs.value + "[${System.currentTimeMillis() % 100000}] $message").takeLast(50)
    }

    // Callbacks for incoming byte payloads
    private val payloadCallback = object : PayloadCallback() {
        override fun onPayloadReceived(endpointId: String, payload: Payload) {
            if (payload.type != Payload.Type.BYTES) return
            val bytes = payload.asBytes() ?: return
            val packet = MeshPacket.fromBytes(bytes) ?: run {
                logDiag("Received invalid or non-MeshPacket payload from $endpointId")
                return
            }
            handleReceivedPacket(endpointId, packet)
        }

        override fun onPayloadTransferUpdate(endpointId: String, update: PayloadTransferUpdate) {
            if (update.status == PayloadTransferUpdate.Status.FAILURE) {
                logDiag("Payload delivery failed to endpoint $endpointId")
            }
        }
    }

    // Callbacks for Nearby Connections lifecycle
    private val connectionLifecycleCallback = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(endpointId: String, info: ConnectionInfo) {
            logDiag("Connection initiated with ${info.endpointName} ($endpointId) [Token: ${info.authenticationDigits}]")

            // Automatically accept peer connections in P2P_CLUSTER mesh
            connectionsClient.acceptConnection(endpointId, payloadCallback)
                .addOnSuccessListener {
                    logDiag("Accepted connection with $endpointId")
                    updatePeerState(
                        endpointId,
                        info.endpointName,
                        PeerConnectionStatus.CONNECTING,
                        info.authenticationDigits
                    )
                }
                .addOnFailureListener { e ->
                    logDiag("Failed accepting connection from $endpointId: ${e.message}")
                    pendingConnectingEndpoints.remove(endpointId)
                }
        }

        override fun onConnectionResult(endpointId: String, resolution: ConnectionResolution) {
            pendingConnectingEndpoints.remove(endpointId)
            when (resolution.status.statusCode) {
                ConnectionsStatusCodes.STATUS_OK -> {
                    logDiag("Connected successfully to peer $endpointId")
                    val currentName = _peers.value[endpointId]?.name ?: "Peer-$endpointId"
                    updatePeerState(endpointId, currentName, PeerConnectionStatus.CONNECTED)
                }
                ConnectionsStatusCodes.STATUS_CONNECTION_REJECTED -> {
                    logDiag("Connection rejected by $endpointId")
                    updatePeerState(endpointId, null, PeerConnectionStatus.FAILED)
                }
                ConnectionsStatusCodes.STATUS_ERROR -> {
                    logDiag("Connection error with $endpointId")
                    updatePeerState(endpointId, null, PeerConnectionStatus.FAILED)
                }
                else -> {
                    logDiag("Connection status code: ${resolution.status.statusCode}")
                }
            }
        }

        override fun onDisconnected(endpointId: String) {
            logDiag("Peer disconnected: $endpointId")
            pendingConnectingEndpoints.remove(endpointId)
            val currentPeer = _peers.value[endpointId]
            if (currentPeer != null) {
                updatePeerState(endpointId, currentPeer.name, PeerConnectionStatus.DISCONNECTED)
            }
        }
    }

    // Callbacks for Endpoint Discovery
    private val endpointDiscoveryCallback = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(endpointId: String, info: DiscoveredEndpointInfo) {
            logDiag("Discovered nearby node: ${info.endpointName} ($endpointId)")
            updatePeerState(endpointId, info.endpointName, PeerConnectionStatus.DISCOVERED)

            // Auto-connect tie-breaker:
            // In P2P_CLUSTER, if two nodes discover each other simultaneously, both sending requestConnection
            // causes collisions. Tie-break using lexicographical comparison of localDeviceId vs discovered endpointName/ID.
            val shouldInitiate = localDeviceId < endpointId && !pendingConnectingEndpoints.contains(endpointId)
            if (shouldInitiate) {
                requestConnectionTo(endpointId, info.endpointName)
            }
        }

        override fun onEndpointLost(endpointId: String) {
            logDiag("Lost radio contact with endpoint $endpointId")
            val currentPeer = _peers.value[endpointId]
            if (currentPeer != null && currentPeer.status != PeerConnectionStatus.CONNECTED) {
                val updated = _peers.value.toMutableMap()
                updated.remove(endpointId)
                _peers.value = updated
            }
        }
    }

    private fun updatePeerState(
        endpointId: String,
        name: String?,
        status: PeerConnectionStatus,
        authDigits: String? = null
    ) {
        val updated = _peers.value.toMutableMap()
        val existing = updated[endpointId]
        val resolvedName = name ?: existing?.name ?: "Node-$endpointId"
        updated[endpointId] = PeerDevice(
            endpointId = endpointId,
            name = resolvedName,
            status = status,
            lastSeenTimestamp = System.currentTimeMillis(),
            isDirectLink = true,
            authenticationDigits = authDigits ?: existing?.authenticationDigits
        )
        _peers.value = updated
    }

    /**
     * Start both Advertising and Discovery to form a symmetrical P2P_CLUSTER mesh network
     */
    fun startMesh() {
        startAdvertising()
        startDiscovery()
    }

    fun stopMesh() {
        stopAdvertising()
        stopDiscovery()
        connectionsClient.stopAllEndpoints()
        _peers.value = emptyMap()
        pendingConnectingEndpoints.clear()
        logDiag("Stopped mesh networking and disconnected all links")
    }

    fun startAdvertising() {
        if (_isAdvertising.value) return
        val advertisingOptions = AdvertisingOptions.Builder()
            .setStrategy(strategy)
            .build()

        connectionsClient.startAdvertising(
            localNickname,
            serviceId,
            connectionLifecycleCallback,
            advertisingOptions
        ).addOnSuccessListener {
            _isAdvertising.value = true
            logDiag("Advertising started as '$localNickname'")
        }.addOnFailureListener { e ->
            logDiag("Advertising failed to start: ${e.message}")
        }
    }

    fun stopAdvertising() {
        connectionsClient.stopAdvertising()
        _isAdvertising.value = false
        logDiag("Advertising stopped")
    }

    fun startDiscovery() {
        if (_isDiscovering.value) return
        val discoveryOptions = DiscoveryOptions.Builder()
            .setStrategy(strategy)
            .build()

        connectionsClient.startDiscovery(
            serviceId,
            endpointDiscoveryCallback,
            discoveryOptions
        ).addOnSuccessListener {
            _isDiscovering.value = true
            logDiag("Discovery started on $serviceId")
        }.addOnFailureListener { e ->
            logDiag("Discovery failed to start: ${e.message}")
        }
    }

    fun stopDiscovery() {
        connectionsClient.stopDiscovery()
        _isDiscovering.value = false
        logDiag("Discovery stopped")
    }

    fun requestConnectionTo(endpointId: String, peerName: String) {
        if (pendingConnectingEndpoints.contains(endpointId)) return
        pendingConnectingEndpoints.add(endpointId)
        logDiag("Requesting connection to $peerName ($endpointId)")
        updatePeerState(endpointId, peerName, PeerConnectionStatus.CONNECTING)

        connectionsClient.requestConnection(
            localNickname,
            endpointId,
            connectionLifecycleCallback
        ).addOnFailureListener { e ->
            pendingConnectingEndpoints.remove(endpointId)
            logDiag("Connection request to $endpointId failed: ${e.message}")
            updatePeerState(endpointId, peerName, PeerConnectionStatus.FAILED)
        }
    }

    fun disconnectPeer(endpointId: String) {
        connectionsClient.disconnectFromEndpoint(endpointId)
        updatePeerState(endpointId, null, PeerConnectionStatus.DISCONNECTED)
    }

    /**
     * Send an outgoing chat message from this device into the mesh
     */
    fun sendMessage(content: String, recipientId: String = MessageEntity.BROADCAST_RECIPIENT) {
        val messageId = UUID.randomUUID().toString()
        val path = listOf(localNickname)

        val packet = MeshPacket(
            packetId = messageId,
            type = PacketType.CHAT,
            senderId = localDeviceId,
            senderNickname = localNickname,
            recipientId = recipientId,
            content = content,
            timestamp = System.currentTimeMillis(),
            hopCount = 0,
            maxHops = 4,
            traversedPath = path
        )

        // Mark as seen locally to prevent reflecting back
        seenMessageIds.add(messageId)

        val connectedEndpoints = _peers.value.filter { it.value.status == PeerConnectionStatus.CONNECTED }.keys.toList()

        val initialStatus = if (connectedEndpoints.isNotEmpty()) DeliveryStatus.SENT else DeliveryStatus.SENDING

        // Save locally to Room
        scope.launch {
            database.messageDao().insertMessage(
                MessageEntity(
                    id = messageId,
                    senderId = localDeviceId,
                    senderNickname = localNickname,
                    recipientId = recipientId,
                    content = content,
                    timestamp = packet.timestamp,
                    isMine = true,
                    hopCount = 0,
                    pathSummary = "Direct",
                    deliveryStatus = initialStatus
                )
            )
        }

        if (connectedEndpoints.isEmpty()) {
            logDiag("Message queued locally: No active peers connected yet")
            return
        }

        // Broadcast payload over all direct links in cluster
        val payload = Payload.fromBytes(packet.toBytes())
        connectionsClient.sendPayload(connectedEndpoints, payload)
            .addOnSuccessListener {
                packetsSent.value += 1
                logDiag("Sent message to ${connectedEndpoints.size} direct peer(s)")
            }
            .addOnFailureListener { e ->
                logDiag("Failed sending packet: ${e.message}")
                scope.launch {
                    database.messageDao().updateDeliveryStatus(messageId, DeliveryStatus.FAILED)
                }
            }
    }

    /**
     * Process received byte packet, store locally if new, and perform Multi-Hop Mesh Relay
     */
    private fun handleReceivedPacket(incomingEndpointId: String, packet: MeshPacket) {
        // Step 1: Duplicate / Loop Prevention
        if (seenMessageIds.contains(packet.packetId)) {
            packetsDroppedDuplicates.value += 1
            logDiag("Loop detected: Dropping duplicate packet ${packet.packetId.take(6)} from $incomingEndpointId")
            return
        }

        // Step 2: Register in seen cache
        seenMessageIds.add(packet.packetId)
        packetsReceived.value += 1

        val pathSummary = when {
            packet.hopCount == 0 -> "Direct link"
            packet.traversedPath.isNotEmpty() -> packet.traversedPath.joinToString(" ➔ ") + " ➔ Me"
            else -> "Relayed (${packet.hopCount} hops)"
        }

        logDiag("Received [${packet.type}] from ${packet.senderNickname} (Hops: ${packet.hopCount}, Path: $pathSummary)")

        // Step 3: Save to local Room database so it is persisted offline
        scope.launch {
            database.messageDao().insertMessage(
                MessageEntity(
                    id = packet.packetId,
                    senderId = packet.senderId,
                    senderNickname = packet.senderNickname,
                    recipientId = packet.recipientId,
                    content = packet.content,
                    timestamp = packet.timestamp,
                    isMine = (packet.senderId == localDeviceId),
                    hopCount = packet.hopCount,
                    pathSummary = pathSummary,
                    deliveryStatus = if (packet.hopCount == 0) DeliveryStatus.DELIVERED else DeliveryStatus.RELAYED
                )
            )
        }

        // Step 4: Multi-hop Mesh Relay Forwarding
        // If the packet has remaining hops allowed, forward it to all other connected peers except the sender
        if (packet.hopCount < packet.maxHops) {
            val forwardEndpoints = _peers.value
                .filter { it.key != incomingEndpointId && it.value.status == PeerConnectionStatus.CONNECTED }
                .keys
                .toList()

            if (forwardEndpoints.isNotEmpty()) {
                val nextHops = packet.hopCount + 1
                val updatedPath = packet.traversedPath + localNickname
                val relayedPacket = packet.copy(
                    hopCount = nextHops,
                    traversedPath = updatedPath
                )
                val relayPayload = Payload.fromBytes(relayedPacket.toBytes())

                connectionsClient.sendPayload(forwardEndpoints, relayPayload)
                    .addOnSuccessListener {
                        packetsRelayed.value += 1
                        logDiag("Relayed packet ${packet.packetId.take(6)} to ${forwardEndpoints.size} other peer(s) [Hop: $nextHops/${packet.maxHops}]")
                    }
                    .addOnFailureListener { e ->
                        logDiag("Failed relaying packet to peers: ${e.message}")
                    }
            } else {
                logDiag("No secondary peers available to forward packet ${packet.packetId.take(6)}")
            }
        } else {
            logDiag("Max hop count (${packet.maxHops}) reached for packet ${packet.packetId.take(6)}; halting relay")
        }
    }
}

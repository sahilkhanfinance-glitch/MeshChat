package com.meshchat.app.mesh

enum class PeerConnectionStatus {
    DISCOVERED,
    CONNECTING,
    CONNECTED,
    DISCONNECTED,
    FAILED
}

data class PeerDevice(
    val endpointId: String,
    val name: String,
    val status: PeerConnectionStatus = PeerConnectionStatus.DISCOVERED,
    val lastSeenTimestamp: Long = System.currentTimeMillis(),
    val isDirectLink: Boolean = true,
    val authenticationDigits: String? = null
)

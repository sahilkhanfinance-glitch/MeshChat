package com.meshchat.app.ui.theme

import androidx.compose.ui.graphics.Color

val CyberCyan = Color(0xFF00E5FF)
val ElectricBlue = Color(0xFF0284C7)
val EmeraldGreen = Color(0xFF10B981)
val WarningAmber = Color(0xFFF59E0B)
val CrimsonRed = Color(0xFFEF4444)

val DarkBackground = Color(0xFF090D16)
val DarkSurface = Color(0xFF111827)
val DarkSurfaceVariant = Color(0xFF1F2937)
val DarkBorder = Color(0xFF374151)

val TextPrimary = Color(0xFFF9FAFB)
val TextSecondary = Color(0xFF9CA3AF)
val TextMuted = Color(0xFF6B7280)

val MyBubbleColor = Color(0xFF0D5E63)
val PeerBubbleColor = Color(0xFF1E293B)

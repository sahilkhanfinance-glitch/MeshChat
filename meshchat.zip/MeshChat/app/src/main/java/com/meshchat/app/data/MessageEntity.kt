package com.meshchat.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class DeliveryStatus {
    SENDING,
    SENT,
    DELIVERED,
    RELAYED,
    FAILED
}

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey
    val id: String,
    val senderId: String,
    val senderNickname: String,
    val recipientId: String = BROADCAST_RECIPIENT,
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isMine: Boolean,
    val hopCount: Int = 0,
    val pathSummary: String = "",
    val deliveryStatus: DeliveryStatus = DeliveryStatus.SENT
) {
    companion object {
        const val BROADCAST_RECIPIENT = "*"
    }
}

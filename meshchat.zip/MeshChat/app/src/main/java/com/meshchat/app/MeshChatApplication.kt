package com.meshchat.app

import android.app.Application
import com.meshchat.app.data.AppDatabase
import com.meshchat.app.mesh.NearbyMeshManager

class MeshChatApplication : Application() {

    lateinit var database: AppDatabase
        private set

    lateinit var meshManager: NearbyMeshManager
        private set

    override fun onCreate() {
        super.onCreate()
        database = AppDatabase.getDatabase(this)
        meshManager = NearbyMeshManager(this)
    }
}

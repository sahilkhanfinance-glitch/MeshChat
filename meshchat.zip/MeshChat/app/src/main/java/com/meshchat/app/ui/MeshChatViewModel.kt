package com.meshchat.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.meshchat.app.MeshChatApplication
import com.meshchat.app.data.DeliveryStatus
import com.meshchat.app.data.MessageEntity
import com.meshchat.app.mesh.NearbyMeshManager
import com.meshchat.app.mesh.PeerConnectionStatus
import com.meshchat.app.mesh.PeerDevice
import com.meshchat.app.service.MeshForegroundService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class MeshStats(
    val sent: Int = 0,
    val received: Int = 0,
    val relayed: Int = 0,
    val duplicatesDropped: Int = 0
)

class MeshChatViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as MeshChatApplication
    private val meshManager: NearbyMeshManager = app.meshManager
    private val messageDao = app.database.messageDao()

    val localDeviceId: String = meshManager.localDeviceId

    private val _localNickname = MutableStateFlow(meshManager.localNickname)
    val localNickname: StateFlow<String> = _localNickname.asStateFlow()

    private val _selectedRecipient = MutableStateFlow<String>(MessageEntity.BROADCAST_RECIPIENT)
    val selectedRecipient: StateFlow<String> = _selectedRecipient.asStateFlow()

    private val _isServiceRunning = MutableStateFlow(false)
    val isServiceRunning: StateFlow<Boolean> = _isServiceRunning.asStateFlow()

    // Mesh status flows from NearbyMeshManager
    val isAdvertising = meshManager.isAdvertising
    val isDiscovering = meshManager.isDiscovering
    val diagnosticLogs = meshManager.diagnosticLogs

    // Peer lists mapped to a sorted list
    val peers: StateFlow<List<PeerDevice>> = meshManager.peers.map { map ->
        map.values.sortedWith(
            compareByDescending<PeerDevice> { it.status == PeerConnectionStatus.CONNECTED }
                .thenByDescending { it.status == PeerConnectionStatus.CONNECTING }
                .thenByDescending { it.status == PeerConnectionStatus.DISCOVERED }
                .thenByDescending { it.lastSeenTimestamp }
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val connectedPeersCount: StateFlow<Int> = meshManager.peers.map { map ->
        map.values.count { it.status == PeerConnectionStatus.CONNECTED }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    // Dynamic message stream based on selected recipient or broadcast
    val messages: StateFlow<List<MessageEntity>> = _selectedRecipient.flatMapLatest { recipient ->
        if (recipient == MessageEntity.BROADCAST_RECIPIENT) {
            messageDao.getAllMessagesFlow()
        } else {
            messageDao.getConversationFlow(recipient)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Aggregated Mesh statistics
    val stats: StateFlow<MeshStats> = combine(
        meshManager.packetsSent,
        meshManager.packetsReceived,
        meshManager.packetsRelayed,
        meshManager.packetsDroppedDuplicates
    ) { sent, received, relayed, dropped ->
        MeshStats(sent, received, relayed, dropped)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), MeshStats())

    init {
        // Automatically start advertising and discovery on launch
        meshManager.startMesh()
    }

    fun setRecipient(recipientId: String) {
        _selectedRecipient.value = recipientId
    }

    fun updateNickname(newName: String) {
        val trimmed = newName.trim()
        if (trimmed.isNotEmpty()) {
            _localNickname.value = trimmed
            meshManager.localNickname = trimmed
            // Restart advertising to broadcast new display name
            meshManager.stopAdvertising()
            meshManager.startAdvertising()
        }
    }

    fun sendMessage(content: String) {
        val trimmed = content.trim()
        if (trimmed.isEmpty()) return
        meshManager.sendMessage(trimmed, _selectedRecipient.value)
    }

    fun connectToPeer(endpointId: String, name: String) {
        meshManager.requestConnectionTo(endpointId, name)
    }

    fun disconnectPeer(endpointId: String) {
        meshManager.disconnectPeer(endpointId)
    }

    fun restartMesh() {
        meshManager.stopMesh()
        meshManager.startMesh()
    }

    fun toggleBackgroundService() {
        if (_isServiceRunning.value) {
            MeshForegroundService.stop(getApplication())
            _isServiceRunning.value = false
        } else {
            MeshForegroundService.start(getApplication())
            _isServiceRunning.value = true
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            messageDao.clearAll()
        }
    }

    override fun onCleared() {
        super.onCleared()
        // If foreground service is NOT active, cleanup on ViewModel destroy
        if (!_isServiceRunning.value) {
            meshManager.stopMesh()
        }
    }
}

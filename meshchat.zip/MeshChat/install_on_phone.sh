#!/usr/bin/env bash
# ==============================================================================
# MeshChat - Zero-Studio Build & Direct Install Script
# ==============================================================================
# This script compiles the native Android APK using Gradle and installs it
# directly onto connected real Android phone(s) over USB or Wi-Fi ADB.
# ==============================================================================

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "=========================================================="
echo "  ⚡ MeshChat Native Android Build & Device Flasher"
echo "=========================================================="

# Check ADB
if command -v adb >/dev/null 2>&1; then
    echo "✓ ADB detected: $(adb version | head -n 1)"
else
    echo "⚠️ Warning: 'adb' command not found in PATH."
    echo "  To install ADB on Linux: sudo apt install adb"
    echo "  To install ADB on macOS: brew install android-platform-tools"
    echo "  To install ADB on Windows: scoop install adb or download platform-tools"
fi

# Build APK
echo ""
echo "📦 Compiling Debug APK via Gradle..."
chmod +x ./gradlew
./gradlew assembleDebug

APK_PATH="app/build/outputs/apk/debug/app-debug.apk"

if [ -f "$APK_PATH" ]; then
    echo ""
    echo "🎉 SUCCESS: APK generated at:"
    echo "   $SCRIPT_DIR/$APK_PATH"
    echo ""
    
    if command -v adb >/dev/null 2>&1; then
        echo "📲 Checking for connected Android devices via ADB..."
        DEVICES=$(adb devices | grep -v "List" | grep "device" || true)
        
        if [ -n "$DEVICES" ]; then
            echo "Found active device(s):"
            echo "$DEVICES"
            echo ""
            echo "Installing MeshChat to all connected devices..."
            adb devices | grep -v "List" | grep "device" | awk '{print $1}' | while read -r device_id; do
                echo "-> Installing to $device_id..."
                adb -s "$device_id" install -r "$APK_PATH"
                echo "-> Launching MeshChat on $device_id..."
                adb -s "$device_id" shell am start -n com.meshchat.app/.MainActivity
            done
            echo "✓ Installation & launch complete!"
        else
            echo "No Android phones currently detected via ADB."
            echo "To install manually:"
            echo "1. Connect your phone via USB with 'USB Debugging' enabled in Developer Options."
            echo "2. Run: adb install -r $APK_PATH"
            echo "3. Or transfer $APK_PATH to your phone via USB file transfer or Google Drive and tap to install."
        fi
    fi
else
    echo "❌ Error: Could not locate built APK."
    exit 1
fi
